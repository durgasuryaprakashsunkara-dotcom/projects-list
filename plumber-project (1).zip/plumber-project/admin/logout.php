<?php
// admin/logout.php
require_once '../includes/config.php';
session_destroy();
redirect(APP_URL . '/pages/login.php');
