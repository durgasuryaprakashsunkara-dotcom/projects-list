<?php
// admin/dashboard.php
require_once '../includes/config.php';
if (!isAdminLoggedIn()) { redirect(APP_URL . '/pages/login.php'); }
$pageTitle = 'Admin Dashboard';

// Stats
$totalPlumbers  = $conn->query("SELECT COUNT(*) FROM plumbers")->fetch_row()[0];
$totalCustomers = $conn->query("SELECT COUNT(*) FROM customers")->fetch_row()[0];
$totalBookings  = $conn->query("SELECT COUNT(*) FROM bookings")->fetch_row()[0];
$pendingBookings= $conn->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetch_row()[0];
$totalContacts  = $conn->query("SELECT COUNT(*) FROM contacts WHERE is_read=0")->fetch_row()[0];
$revenue        = $conn->query("SELECT SUM(total_charge) FROM bookings WHERE status='completed'")->fetch_row()[0] ?? 0;

// Recent bookings
$recentBookings = $conn->query("SELECT b.*,c.name AS cname,p.name AS pname FROM bookings b JOIN customers c ON b.customer_id=c.id JOIN plumbers p ON b.plumber_id=p.id ORDER BY b.created_at DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);

// Recent plumbers
$recentPlumbers = $conn->query("SELECT * FROM plumbers ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard | <?php echo APP_NAME; ?></title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/plumber-service.css">
</head>
<body style="padding-top:0">

<div class="admin-layout">
  <!-- Sidebar -->
  <aside class="admin-sidebar" id="adminSidebar">
    <div class="sidebar-logo">
      <div class="logo-icon" style="width:36px;height:36px;background:var(--accent-gradient);border-radius:8px;display:flex;align-items:center;justify-content:center;color:#fff;flex-shrink:0"><i class="fas fa-wrench"></i></div>
      <span class="logo-text">Plumber<span>Pro</span></span>
    </div>
    <nav class="sidebar-nav">
      <div class="sidebar-section-label">Main</div>
      <a href="dashboard.php" class="sidebar-nav-item active"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a>
      <a href="plumbers.php" class="sidebar-nav-item"><i class="fas fa-hard-hat"></i><span>Plumbers</span></a>
      <a href="customers.php" class="sidebar-nav-item"><i class="fas fa-users"></i><span>Customers</span></a>
      <a href="bookings.php" class="sidebar-nav-item">
        <i class="fas fa-calendar-check"></i><span>Bookings</span>
        <?php if($pendingBookings): ?><span class="badge"><?php echo $pendingBookings; ?></span><?php endif; ?>
      </a>
      <div class="sidebar-section-label">Manage</div>
      <a href="services.php" class="sidebar-nav-item"><i class="fas fa-tools"></i><span>Services</span></a>
      <a href="contacts.php" class="sidebar-nav-item">
        <i class="fas fa-envelope"></i><span>Messages</span>
        <?php if($totalContacts): ?><span class="badge"><?php echo $totalContacts; ?></span><?php endif; ?>
      </a>
      <a href="reviews.php" class="sidebar-nav-item"><i class="fas fa-star"></i><span>Reviews</span></a>
      <div class="sidebar-section-label">Account</div>
      <a href="<?php echo APP_URL; ?>/index.php" class="sidebar-nav-item"><i class="fas fa-globe"></i><span>View Site</span></a>
      <a href="logout.php" class="sidebar-nav-item"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a>
    </nav>
  </aside>

  <!-- Main -->
  <div class="admin-main">
    <!-- Topbar -->
    <div class="admin-topbar">
      <div class="d-flex align-items-center gap-3">
        <button class="topbar-icon-btn" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <span class="topbar-title">Dashboard</span>
      </div>
      <div class="topbar-actions">
        <button class="topbar-icon-btn">
          <i class="fas fa-bell"></i>
          <?php if($pendingBookings): ?><span class="badge-dot"></span><?php endif; ?>
        </button>
        <div class="admin-user-chip">
          <div style="width:36px;height:36px;border-radius:50%;background:var(--primary-gradient);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700">
            <?php echo strtoupper(substr($_SESSION['admin_name'],0,1)); ?>
          </div>
          <span class="name"><?php echo htmlspecialchars($_SESSION['admin_name']); ?></span>
        </div>
      </div>
    </div>

    <div class="admin-content">

      <!-- Stat Cards -->
      <div class="row g-4 mb-5">
        <div class="col-xl-2 col-md-4 col-6">
          <div class="stat-card">
            <div class="stat-icon blue"><i class="fas fa-hard-hat"></i></div>
            <div class="stat-info">
              <div class="stat-number"><?php echo $totalPlumbers; ?></div>
              <div class="stat-label">Plumbers</div>
              <span class="stat-change up"><i class="fas fa-arrow-up"></i> Active</span>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
          <div class="stat-card">
            <div class="stat-icon orange"><i class="fas fa-users"></i></div>
            <div class="stat-info">
              <div class="stat-number"><?php echo $totalCustomers; ?></div>
              <div class="stat-label">Customers</div>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
          <div class="stat-card">
            <div class="stat-icon green"><i class="fas fa-calendar-check"></i></div>
            <div class="stat-info">
              <div class="stat-number"><?php echo $totalBookings; ?></div>
              <div class="stat-label">Bookings</div>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
          <div class="stat-card">
            <div class="stat-icon purple"><i class="fas fa-clock"></i></div>
            <div class="stat-info">
              <div class="stat-number"><?php echo $pendingBookings; ?></div>
              <div class="stat-label">Pending</div>
              <?php if($pendingBookings): ?><span class="stat-change down">Needs action</span><?php endif; ?>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
          <div class="stat-card">
            <div class="stat-icon red"><i class="fas fa-envelope"></i></div>
            <div class="stat-info">
              <div class="stat-number"><?php echo $totalContacts; ?></div>
              <div class="stat-label">Unread Msgs</div>
            </div>
          </div>
        </div>
        <div class="col-xl-2 col-md-4 col-6">
          <div class="stat-card">
            <div class="stat-icon green"><i class="fas fa-rupee-sign"></i></div>
            <div class="stat-info">
              <div class="stat-number">₹<?php echo number_format($revenue,0); ?></div>
              <div class="stat-label">Revenue</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Recent Bookings Table -->
      <div class="admin-table-card mb-5">
        <div class="admin-table-header">
          <span class="admin-table-title">Recent Bookings</span>
          <a href="bookings.php" class="btn btn-primary-custom btn-sm">View All</a>
        </div>
        <div class="table-responsive">
          <table class="table-custom">
            <thead>
              <tr>
                <th>#ID</th>
                <th>Customer</th>
                <th>Plumber</th>
                <th>Service</th>
                <th>Date</th>
                <th>Charge</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($recentBookings)): ?>
              <tr><td colspan="8" class="text-center text-muted py-4">No bookings yet.</td></tr>
              <?php else: ?>
              <?php foreach ($recentBookings as $b): ?>
              <tr>
                <td><strong>#<?php echo $b['id']; ?></strong></td>
                <td><?php echo htmlspecialchars($b['cname']); ?></td>
                <td><?php echo htmlspecialchars($b['pname']); ?></td>
                <td><?php echo htmlspecialchars($b['service_type']); ?></td>
                <td><?php echo date('d M Y', strtotime($b['booking_date'])); ?></td>
                <td>₹<?php echo number_format($b['total_charge'],0); ?></td>
                <td><span class="status-badge <?php echo $b['status']; ?>"><?php echo ucfirst($b['status']); ?></span></td>
                <td>
                  <a href="booking-detail.php?id=<?php echo $b['id']; ?>" class="table-action-btn view"><i class="fas fa-eye"></i></a>
                  <a href="delete-booking.php?id=<?php echo $b['id']; ?>" class="table-action-btn delete" onclick="return confirm('Delete this booking?')"><i class="fas fa-trash"></i></a>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Recent Plumbers -->
      <div class="admin-table-card">
        <div class="admin-table-header">
          <span class="admin-table-title">Recently Registered Plumbers</span>
          <a href="plumbers.php" class="btn btn-primary-custom btn-sm">View All</a>
        </div>
        <div class="table-responsive">
          <table class="table-custom">
            <thead>
              <tr><th>Name</th><th>Phone</th><th>Area</th><th>Experience</th><th>Rating</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
              <?php foreach ($recentPlumbers as $pl): ?>
              <tr>
                <td>
                  <div class="table-avatar">
                    <div style="width:36px;height:36px;border-radius:50%;background:var(--primary-gradient);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.9rem">
                      <?php echo strtoupper(substr($pl['name'],0,1)); ?>
                    </div>
                    <div>
                      <div class="name"><?php echo htmlspecialchars($pl['name']); ?></div>
                      <div class="email"><?php echo htmlspecialchars($pl['email']); ?></div>
                    </div>
                  </div>
                </td>
                <td><?php echo htmlspecialchars($pl['phone']); ?></td>
                <td><?php echo htmlspecialchars($pl['service_area']); ?></td>
                <td><?php echo $pl['experience']; ?> yrs</td>
                <td><?php echo $pl['rating']; ?> ★</td>
                <td><span class="status-badge <?php echo $pl['status']; ?>"><?php echo ucfirst($pl['status']); ?></span></td>
                <td>
                  <a href="plumber-detail.php?id=<?php echo $pl['id']; ?>" class="table-action-btn view"><i class="fas fa-eye"></i></a>
                  <a href="edit-plumber.php?id=<?php echo $pl['id']; ?>" class="table-action-btn edit"><i class="fas fa-edit"></i></a>
                  <a href="delete-plumber.php?id=<?php echo $pl['id']; ?>" class="table-action-btn delete" onclick="return confirm('Delete?')"><i class="fas fa-trash"></i></a>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <div class="pagination-custom">
          <button class="page-btn" disabled><i class="fas fa-chevron-left"></i></button>
          <button class="page-btn active">1</button>
          <button class="page-btn">2</button>
          <button class="page-btn">3</button>
          <button class="page-btn"><i class="fas fa-chevron-right"></i></button>
        </div>
      </div>

    </div><!-- /admin-content -->
  </div><!-- /admin-main -->
</div><!-- /admin-layout -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo APP_URL; ?>/js/main.js"></script>
<script>
  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('adminSidebar').classList.toggle('collapsed');
  });
</script>
</body>
</html>
