<?php
// includes/header.php
if (!defined('APP_NAME')) require_once __DIR__ . '/config.php';
$flash = renderFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="PlumberPro – Find trusted plumbers near you. Book a service online instantly.">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' | ' . APP_NAME : APP_NAME; ?></title>

    <!-- Bootstrap 5 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- Google Fonts: Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/plumber-service.css">
    <?php if (isset($extraCss)) echo $extraCss; ?>
</head>
<body class="<?php echo isset($bodyClass) ? htmlspecialchars($bodyClass) : ''; ?>">

<!-- ==================== NAVBAR ==================== -->
<nav class="navbar navbar-custom navbar-expand-lg" id="mainNavbar">
  <div class="container">
    <!-- Logo -->
    <a class="navbar-brand-custom" href="<?php echo APP_URL; ?>/index.php">
      <div class="logo-icon"><i class="fas fa-wrench"></i></div>
      <span class="logo-text-main">Plumber</span><span class="logo-text-accent">Pro</span>
    </a>

    <!-- Hamburger -->
    <button class="navbar-toggler-custom d-lg-none" id="navToggler" aria-label="Toggle navigation">
      <span></span><span></span><span></span>
    </button>

    <!-- Nav Links -->
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto navbar-nav-custom align-items-lg-center">
        <li class="nav-item">
          <a class="nav-link-custom <?php echo basename($_SERVER['PHP_SELF'])=='index.php'?'active':''; ?>" href="<?php echo APP_URL; ?>/index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link-custom <?php echo basename($_SERVER['PHP_SELF'])=='plumbers.php'?'active':''; ?>" href="<?php echo APP_URL; ?>/pages/plumbers.php">Find Plumber</a>
        </li>
        <li class="nav-item">
          <a class="nav-link-custom <?php echo basename($_SERVER['PHP_SELF'])=='register-plumber.php'?'active':''; ?>" href="<?php echo APP_URL; ?>/pages/register-plumber.php">Register as Plumber</a>
        </li>
        <li class="nav-item">
          <a class="nav-link-custom <?php echo basename($_SERVER['PHP_SELF'])=='about.php'?'active':''; ?>" href="<?php echo APP_URL; ?>/pages/about.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link-custom <?php echo basename($_SERVER['PHP_SELF'])=='contact.php'?'active':''; ?>" href="<?php echo APP_URL; ?>/pages/contact.php">Contact</a>
        </li>
        <?php if (isLoggedIn()): ?>
        <li class="nav-item">
          <a class="nav-link-custom nav-btn-login" href="<?php echo APP_URL; ?>/pages/dashboard.php">
            <i class="fas fa-user-circle me-1"></i>My Account
          </a>
        </li>
        <?php elseif (isPlumberLoggedIn()): ?>
        <li class="nav-item">
          <a class="nav-link-custom nav-btn-login" href="<?php echo APP_URL; ?>/pages/plumber-dashboard.php">
            <i class="fas fa-tachometer-alt me-1"></i>Dashboard
          </a>
        </li>
        <?php else: ?>
        <li class="nav-item">
          <a class="nav-link-custom nav-btn-login" href="<?php echo APP_URL; ?>/pages/login.php">
            <i class="fas fa-sign-in-alt me-1"></i>Login
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>

<!-- Flash Message -->
<?php if ($flash): ?>
<div class="container mt-3"><?php echo $flash; ?></div>
<?php endif; ?>
