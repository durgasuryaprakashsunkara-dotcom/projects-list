<?php // includes/footer.php ?>

<!-- ==================== FOOTER ==================== -->
<footer class="footer-custom">
  <div class="footer-top">
    <div class="container">
      <div class="row g-5">

        <!-- Brand -->
        <div class="col-lg-4 col-md-6">
          <div class="footer-brand">
            <div class="logo-icon"><i class="fas fa-wrench"></i></div>
            <span class="brand-name">Plumber<span>Pro</span></span>
          </div>
          <p class="footer-description">Your trusted partner for professional plumbing services. Available 24/7 across Andhra Pradesh.</p>
          <div class="footer-social">
            <a href="#" class="footer-social-btn" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="footer-social-btn" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
            <a href="#" class="footer-social-btn" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
            <a href="https://wa.me/919876543210" class="footer-social-btn" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
            <a href="#" class="footer-social-btn" aria-label="YouTube"><i class="fab fa-youtube"></i></a>
          </div>
        </div>

        <!-- Quick Links -->
        <div class="col-lg-2 col-md-3 col-6">
          <h5 class="footer-heading">Quick Links</h5>
          <ul class="footer-links">
            <li><a href="<?php echo APP_URL; ?>/index.php"><i class="fas fa-chevron-right"></i>Home</a></li>
            <li><a href="<?php echo APP_URL; ?>/pages/plumbers.php"><i class="fas fa-chevron-right"></i>Find Plumber</a></li>
            <li><a href="<?php echo APP_URL; ?>/pages/register-plumber.php"><i class="fas fa-chevron-right"></i>Register</a></li>
            <li><a href="<?php echo APP_URL; ?>/pages/about.php"><i class="fas fa-chevron-right"></i>About Us</a></li>
            <li><a href="<?php echo APP_URL; ?>/pages/contact.php"><i class="fas fa-chevron-right"></i>Contact</a></li>
          </ul>
        </div>

        <!-- Services -->
        <div class="col-lg-2 col-md-3 col-6">
          <h5 class="footer-heading">Services</h5>
          <ul class="footer-links">
            <li><a href="#"><i class="fas fa-chevron-right"></i>Pipe Repair</a></li>
            <li><a href="#"><i class="fas fa-chevron-right"></i>Drain Cleaning</a></li>
            <li><a href="#"><i class="fas fa-chevron-right"></i>Water Heater</a></li>
            <li><a href="#"><i class="fas fa-chevron-right"></i>Bathroom Fitting</a></li>
            <li><a href="#"><i class="fas fa-chevron-right"></i>Emergency 24/7</a></li>
          </ul>
        </div>

        <!-- Contact -->
        <div class="col-lg-4 col-md-6">
          <h5 class="footer-heading">Contact Us</h5>
          <ul class="footer-contact-list">
            <li><i class="fas fa-map-marker-alt"></i>MG Road, Vijayawada, Andhra Pradesh – 520010</li>
            <li><i class="fas fa-phone-alt"></i><a href="tel:+919876543210" style="color:inherit">+91 98765 43210</a></li>
            <li><i class="fas fa-envelope"></i><a href="mailto:info@plumberpro.com" style="color:inherit">info@plumberpro.com</a></li>
            <li><i class="fas fa-clock"></i>Mon – Sat: 8:00 AM – 8:00 PM</li>
          </ul>
        </div>

      </div>
    </div>
  </div>

  <!-- Footer Bottom -->
  <div class="container">
    <div class="footer-bottom">
      <p class="footer-copyright mb-0">
        &copy; <?php echo date('Y'); ?> <a href="<?php echo APP_URL; ?>">PlumberPro</a>. All rights reserved.
      </p>
      <div class="footer-bottom-links">
        <a href="#">Privacy Policy</a>
        <a href="#">Terms of Service</a>
        <a href="#">Sitemap</a>
      </div>
    </div>
  </div>
</footer>

<!-- Back To Top -->
<button class="back-to-top" id="backToTop" aria-label="Back to top">
  <i class="fas fa-chevron-up"></i>
</button>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Custom JS -->
<script src="<?php echo APP_URL; ?>/js/main.js"></script>
<?php if (isset($extraJs)) echo $extraJs; ?>
</body>
</html>
