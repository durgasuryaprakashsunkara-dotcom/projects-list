<?php
// ============================================================
// includes/config.php — Database & App Configuration
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'plumber_db');

define('APP_NAME',    'PlumberPro');
define('APP_URL',     'http://localhost/plumber-project');
define('APP_VERSION', '1.0.0');
define('UPLOAD_PATH', __DIR__ . '/../uploads/profiles/');
define('UPLOAD_URL',  APP_URL . '/uploads/profiles/');

// Session start
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Connection (MySQLi)
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die('<div style="font-family:sans-serif;padding:40px;color:red;">
        <h2>Database Connection Failed</h2>
        <p>' . $conn->connect_error . '</p>
    </div>');
}
$conn->set_charset('utf8mb4');

// ---- Helper Functions ----

function sanitize($data) {
    global $conn;
    return htmlspecialchars(strip_tags(trim($conn->real_escape_string($data))));
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']);
}

function isPlumberLoggedIn() {
    return isset($_SESSION['plumber_id']);
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function renderFlash() {
    $flash = getFlash();
    if (!$flash) return '';
    $icon = ['success'=>'check-circle','danger'=>'times-circle','warning'=>'exclamation-triangle','info'=>'info-circle'][$flash['type']] ?? 'info-circle';
    return '<div class="alert-custom ' . $flash['type'] . '">
        <i class="fas fa-' . $icon . '"></i>
        <span>' . htmlspecialchars($flash['message']) . '</span>
    </div>';
}

function generateStars($rating) {
    $html = '<div class="rating-stars">';
    for ($i = 1; $i <= 5; $i++) {
        $html .= '<i class="fas fa-star star' . ($i <= $rating ? '' : ' empty') . '"></i>';
    }
    $html .= '</div>';
    return $html;
}

function uploadImage($file, $folder = UPLOAD_PATH) {
    $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
    if (!in_array($file['type'], $allowed)) return false;
    if ($file['size'] > 2 * 1024 * 1024) return false;
    $ext      = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid('img_', true) . '.' . $ext;
    $dest     = $folder . $filename;
    if (move_uploaded_file($file['tmp_name'], $dest)) return $filename;
    return false;
}
