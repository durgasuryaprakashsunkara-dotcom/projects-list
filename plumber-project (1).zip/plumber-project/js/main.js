/**
 * PlumberPro — Main JavaScript
 * Handles: Navbar scroll, hamburger, back-to-top,
 *          form validation, image preview, animations,
 *          radio role tabs, and UI interactions.
 */

'use strict';

// ============================================================
// 1. DOM READY
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initBackToTop();
  initFormValidation();
  initImagePreviews();
  initRoleTabs();
  initAnimateOnScroll();
  initPlumberCardRipple();
  initFilterButtons();
  initPhoneFormatter();
  initAutoHideAlerts();
});

// ============================================================
// 2. NAVBAR — Scroll shrink + mobile hamburger
// ============================================================
function initNavbar() {
  const navbar   = document.getElementById('mainNavbar');
  const toggler  = document.getElementById('navToggler');
  const navMenu  = document.getElementById('navbarNav');

  if (!navbar) return;

  // Scroll shrink
  const handleScroll = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 50);
  };
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  // Hamburger toggle
  if (toggler && navMenu) {
    toggler.addEventListener('click', () => {
      const isOpen = navMenu.classList.toggle('show');
      toggler.classList.toggle('open', isOpen);
      toggler.setAttribute('aria-expanded', isOpen);
    });

    // Close nav when clicking outside
    document.addEventListener('click', (e) => {
      if (!navbar.contains(e.target)) {
        navMenu.classList.remove('show');
        toggler.classList.remove('open');
        toggler.setAttribute('aria-expanded', 'false');
      }
    });

    // Close nav when a link is clicked (mobile)
    navMenu.querySelectorAll('.nav-link-custom').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('show');
        toggler.classList.remove('open');
      });
    });
  }
}

// ============================================================
// 3. BACK TO TOP
// ============================================================
function initBackToTop() {
  const btn = document.getElementById('backToTop');
  if (!btn) return;

  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

// ============================================================
// 4. CLIENT-SIDE FORM VALIDATION
// ============================================================
function initFormValidation() {
  // Booking Form
  const bookingForm = document.getElementById('bookingForm');
  if (bookingForm) {
    bookingForm.addEventListener('submit', (e) => {
      if (!validateForm(bookingForm)) {
        e.preventDefault();
        scrollToFirstError(bookingForm);
      }
    });
  }

  // Registration Form
  const regForm = document.getElementById('regForm');
  if (regForm) {
    regForm.addEventListener('submit', (e) => {
      const pw1 = document.getElementById('pw1');
      const pw2 = document.getElementById('pw2');
      if (pw1 && pw2 && pw1.value !== pw2.value) {
        e.preventDefault();
        setFieldError(pw2, 'Passwords do not match.');
        pw2.focus();
        return;
      }
      if (!validateForm(regForm)) {
        e.preventDefault();
        scrollToFirstError(regForm);
      }
    });
  }

  // Contact Form
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      if (!validateForm(contactForm)) {
        e.preventDefault();
        scrollToFirstError(contactForm);
      }
    });
  }

  // Login Form
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      if (!validateForm(loginForm)) {
        e.preventDefault();
      }
    });
  }

  // Live validation on blur
  document.querySelectorAll('.form-control-custom[required]').forEach(input => {
    input.addEventListener('blur', () => validateField(input));
    input.addEventListener('input', () => clearFieldError(input));
  });
}

function validateForm(form) {
  let valid = true;
  form.querySelectorAll('.form-control-custom[required]').forEach(input => {
    if (!validateField(input)) valid = false;
  });
  return valid;
}

function validateField(input) {
  const val = input.value.trim();
  if (!val) {
    setFieldError(input, 'This field is required.');
    return false;
  }
  if (input.type === 'email' && !isValidEmail(val)) {
    setFieldError(input, 'Please enter a valid email address.');
    return false;
  }
  if (input.type === 'tel' && val.length < 10) {
    setFieldError(input, 'Enter a valid 10-digit phone number.');
    return false;
  }
  if (input.type === 'password' && val.length < 6) {
    setFieldError(input, 'Password must be at least 6 characters.');
    return false;
  }
  clearFieldError(input);
  setFieldSuccess(input);
  return true;
}

function setFieldError(input, message) {
  input.classList.remove('is-valid');
  input.classList.add('is-invalid');
  removeFieldFeedback(input);
  const msg = document.createElement('div');
  msg.className = 'invalid-feedback-custom';
  msg.innerHTML = `<i class="fas fa-times-circle"></i> ${message}`;
  input.parentNode.appendChild(msg);
}

function setFieldSuccess(input) {
  removeFieldFeedback(input);
  input.classList.remove('is-invalid');
  input.classList.add('is-valid');
}

function clearFieldError(input) {
  input.classList.remove('is-invalid', 'is-valid');
  removeFieldFeedback(input);
}

function removeFieldFeedback(input) {
  input.parentNode.querySelectorAll('.invalid-feedback-custom,.valid-feedback-custom').forEach(el => el.remove());
}

function scrollToFirstError(form) {
  const firstError = form.querySelector('.is-invalid');
  if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// ============================================================
// 5. IMAGE UPLOAD PREVIEW (Registration Form)
// ============================================================
function initImagePreviews() {
  const fileInput = document.getElementById('profileImg');
  const preview   = document.getElementById('imgPreview');
  const circle    = document.getElementById('uploadCircle');

  if (!fileInput || !preview) return;

  fileInput.addEventListener('change', () => {
    const file = fileInput.files[0];
    if (!file) return;

    // Validate type and size
    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file.', 'danger');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      showToast('Image must be under 2MB.', 'danger');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      preview.src = e.target.result;
      preview.classList.add('loaded');
      circle.querySelector('i')?.remove();
      circle.querySelector('span')?.remove();
    };
    reader.readAsDataURL(file);
  });
}

// ============================================================
// 6. LOGIN ROLE TAB SWITCHER
// ============================================================
function initRoleTabs() {
  const roleBtns = document.querySelectorAll('input[name="role"]');
  if (!roleBtns.length) return;

  roleBtns.forEach(radio => {
    radio.addEventListener('change', () => {
      document.querySelectorAll('label.filter-btn').forEach(lbl => lbl.classList.remove('active'));
      radio.closest('label')?.classList.add('active');
    });
    // Init active state
    if (radio.checked) radio.closest('label')?.classList.add('active');
  });
}

// ============================================================
// 7. ANIMATE ON SCROLL (Intersection Observer)
// ============================================================
function initAnimateOnScroll() {
  if (!('IntersectionObserver' in window)) return;

  const targets = document.querySelectorAll(
    '.plumber-card, .service-icon-card, .step-card, .testimonial-card, .stat-card, .feature-item'
  );

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity   = '1';
          entry.target.style.transform = 'translateY(0)';
        }, i * 60);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  targets.forEach(el => {
    el.style.opacity   = '0';
    el.style.transform = 'translateY(24px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    observer.observe(el);
  });
}

// ============================================================
// 8. PLUMBER CARD HOVER RIPPLE
// ============================================================
function initPlumberCardRipple() {
  document.querySelectorAll('.btn-accent, .btn-primary-custom').forEach(btn => {
    btn.addEventListener('click', function (e) {
      const ripple = document.createElement('span');
      const rect   = this.getBoundingClientRect();
      const size   = Math.max(rect.width, rect.height);
      ripple.style.cssText = `
        position:absolute;left:${e.clientX - rect.left - size/2}px;
        top:${e.clientY - rect.top - size/2}px;
        width:${size}px;height:${size}px;
        border-radius:50%;background:rgba(255,255,255,0.3);
        pointer-events:none;animation:ripple 0.6s linear;
      `;
      this.style.position = 'relative';
      this.style.overflow = 'hidden';
      this.appendChild(ripple);
      setTimeout(() => ripple.remove(), 700);
    });
  });
}

// ============================================================
// 9. FILTER BUTTONS (Plumber listing)
// ============================================================
function initFilterButtons() {
  document.querySelectorAll('.filter-btn[data-filter]').forEach(btn => {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.filter-btn[data-filter]').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });
}

// ============================================================
// 10. PHONE NUMBER FORMATTER (digits only, max 10)
// ============================================================
function initPhoneFormatter() {
  document.querySelectorAll('input[type="tel"]').forEach(input => {
    input.addEventListener('input', () => {
      input.value = input.value.replace(/\D/g, '').slice(0, 10);
    });
  });
}

// ============================================================
// 11. AUTO-HIDE ALERT MESSAGES
// ============================================================
function initAutoHideAlerts() {
  document.querySelectorAll('.alert-custom').forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      alert.style.opacity    = '0';
      alert.style.transform  = 'translateY(-10px)';
      setTimeout(() => alert.remove(), 500);
    }, 5000);
  });
}

// ============================================================
// 12. TOAST NOTIFICATION UTILITY
// ============================================================
function showToast(message, type = 'success', duration = 3500) {
  let container = document.querySelector('.toast-container-custom');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container-custom';
    document.body.appendChild(container);
  }

  const icons = { success: 'check-circle', danger: 'times-circle', warning: 'exclamation-triangle', info: 'info-circle' };
  const toast = document.createElement('div');
  toast.className = `toast-custom ${type}`;
  toast.innerHTML = `<i class="fas fa-${icons[type] || 'info-circle'}"></i><span>${message}</span>`;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity   = '0';
    toast.style.transform = 'translateX(40px)';
    toast.style.transition = 'all 0.4s ease';
    setTimeout(() => toast.remove(), 400);
  }, duration);
}

// ============================================================
// 13. SEARCH INPUT CLEAR BUTTON
// ============================================================
document.querySelectorAll('.search-input-group').forEach(group => {
  const input = group.querySelector('.form-control-custom');
  if (!input) return;

  input.addEventListener('input', () => {
    let clearBtn = group.querySelector('.input-clear');
    if (input.value && !clearBtn) {
      clearBtn = document.createElement('button');
      clearBtn.type      = 'button';
      clearBtn.className = 'input-clear';
      clearBtn.innerHTML = '<i class="fas fa-times"></i>';
      clearBtn.style.cssText = 'position:absolute;right:14px;top:50%;transform:translateY(-50%);border:none;background:none;color:var(--text-muted);cursor:pointer;font-size:.75rem;z-index:5';
      group.appendChild(clearBtn);
      clearBtn.addEventListener('click', () => {
        input.value = '';
        clearBtn.remove();
        input.focus();
      });
    } else if (!input.value && clearBtn) {
      clearBtn.remove();
    }
  });
});

// ============================================================
// 14. ADMIN SIDEBAR TOGGLE (keyboard shortcut)
// ============================================================
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.key === 'b') {
    const sidebar = document.getElementById('adminSidebar');
    if (sidebar) sidebar.classList.toggle('collapsed');
  }
});

// ============================================================
// 15. SMOOTH SCROLL FOR ANCHOR LINKS
// ============================================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ============================================================
// 16. POPULAR SEARCH TAGS → Fill Search Input
// ============================================================
document.querySelectorAll('.popular-tag').forEach(tag => {
  tag.addEventListener('click', (e) => {
    e.preventDefault();
    const url    = new URL(tag.href, window.location.href);
    const service = url.searchParams.get('service');
    const select  = document.querySelector('select[name="service"]');
    if (select && service) {
      select.value = service;
      select.closest('form')?.querySelector('.btn-search')?.focus();
    }
  });
});

// Expose utility globally
window.PlumberPro = { showToast };
