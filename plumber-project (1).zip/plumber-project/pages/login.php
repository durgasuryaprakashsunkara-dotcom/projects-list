<?php
// pages/login.php
require_once '../includes/config.php';
$pageTitle = 'Login';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role'] ?? 'customer';

    $error = '';
    if ($role === 'admin') {
        $stmt = $conn->prepare("SELECT * FROM admins WHERE email=?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if ($user && verifyPassword($password, $user['password'])) {
            $_SESSION['admin_id']   = $user['id'];
            $_SESSION['admin_name'] = $user['name'];
            redirect(APP_URL . '/admin/dashboard.php');
        } else { $error = 'Invalid admin credentials.'; }
    } elseif ($role === 'plumber') {
        $stmt = $conn->prepare("SELECT * FROM plumbers WHERE email=? AND status='active'");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if ($user && verifyPassword($password, $user['password'])) {
            $_SESSION['plumber_id']   = $user['id'];
            $_SESSION['plumber_name'] = $user['name'];
            redirect(APP_URL . '/pages/plumber-dashboard.php');
        } else { $error = 'Invalid plumber credentials or account not active.'; }
    } else {
        $stmt = $conn->prepare("SELECT * FROM customers WHERE email=? AND status='active'");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        if ($user && verifyPassword($password, $user['password'])) {
            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            redirect(APP_URL . '/pages/dashboard.php');
        } else { $error = 'Invalid email or password.'; }
    }
}

require_once '../includes/header.php';
?>

<section class="form-section section-padding" style="min-height:80vh;display:flex;align-items:center">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-5">
        <div class="form-card">
          <div class="form-card-header">
            <div class="form-card-icon"><i class="fas fa-sign-in-alt"></i></div>
            <h2 class="section-title mb-1" style="font-size:1.75rem">Welcome <span>Back</span></h2>
            <p class="text-muted">Sign in to your PlumberPro account</p>
          </div>

          <?php if (!empty($error)): ?>
          <div class="alert-custom danger mb-4"><i class="fas fa-times-circle"></i> <?php echo $error; ?></div>
          <?php endif; ?>

          <form method="POST" id="loginForm">
            <!-- Role Tabs -->
            <div class="d-flex gap-2 mb-5">
              <?php foreach (['customer'=>'Customer','plumber'=>'Plumber','admin'=>'Admin'] as $key=>$label): ?>
              <label class="filter-btn flex-fill text-center" style="cursor:pointer">
                <input type="radio" name="role" value="<?php echo $key; ?>" style="display:none" <?php echo ($key==='customer')?'checked':''; ?>>
                <?php echo $label; ?>
              </label>
              <?php endforeach; ?>
            </div>

            <div class="form-group-custom">
              <label class="form-label-custom"><i class="fas fa-envelope"></i> Email Address</label>
              <input type="email" name="email" class="form-control-custom" placeholder="your@email.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
            </div>
            <div class="form-group-custom">
              <label class="form-label-custom"><i class="fas fa-lock"></i> Password</label>
              <input type="password" name="password" class="form-control-custom" placeholder="Your password" required>
            </div>

            <button type="submit" class="btn btn-primary-custom btn-block btn-lg mt-3">
              <i class="fas fa-sign-in-alt"></i> Login
            </button>
          </form>

          <hr class="my-4">
          <p class="text-center text-muted" style="font-size:.875rem">
            New plumber? <a href="register-plumber.php" style="color:var(--primary);font-weight:600">Register here</a>
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
