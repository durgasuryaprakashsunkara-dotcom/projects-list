<?php
// pages/booking.php — Customer Booking Form
require_once '../includes/config.php';
$pageTitle = 'Book a Plumber';

$plumber_id = (int)($_GET['plumber_id'] ?? 0);
$plumber    = null;
if ($plumber_id) {
    $stmt = $conn->prepare("SELECT * FROM plumbers WHERE id=? AND status='active'");
    $stmt->bind_param('i', $plumber_id);
    $stmt->execute();
    $plumber = $stmt->get_result()->fetch_assoc();
}

// All active plumbers for dropdown
$allPlumbers = $conn->query("SELECT id,name,service_area FROM plumbers WHERE status='active' ORDER BY name")->fetch_all(MYSQLI_ASSOC);
$services    = $conn->query("SELECT * FROM services WHERE status=1")->fetch_all(MYSQLI_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cname    = sanitize($_POST['cname']    ?? '');
    $phone    = sanitize($_POST['phone']    ?? '');
    $email    = sanitize($_POST['email']    ?? '');
    $address  = sanitize($_POST['address']  ?? '');
    $svc_type = sanitize($_POST['service_type'] ?? '');
    $problem  = sanitize($_POST['problem']  ?? '');
    $bdate    = sanitize($_POST['bdate']    ?? '');
    $btime    = sanitize($_POST['btime']    ?? '');
    $pid      = (int)($_POST['plumber_id'] ?? 0);
    $errors   = [];

    if (!$cname)   $errors[] = 'Name is required.';
    if (!$phone || strlen($phone) < 10) $errors[] = 'Valid phone number required.';
    if (!$address) $errors[] = 'Address is required.';
    if (!$svc_type) $errors[] = 'Service type is required.';
    if (!$problem) $errors[] = 'Problem description is required.';
    if (!$bdate)   $errors[] = 'Booking date is required.';
    if (!$btime)   $errors[] = 'Booking time is required.';
    if (!$pid)     $errors[] = 'Please select a plumber.';

    if (empty($errors)) {
        // Check or create customer
        $custStmt = $conn->prepare("SELECT id FROM customers WHERE phone=?");
        $custStmt->bind_param('s', $phone);
        $custStmt->execute();
        $cust = $custStmt->get_result()->fetch_assoc();
        if ($cust) {
            $cust_id = $cust['id'];
        } else {
            $pw = hashPassword('customer123');
            $ins = $conn->prepare("INSERT INTO customers (name,email,phone,password,address) VALUES (?,?,?,?,?)");
            $ins->bind_param('sssss', $cname, $email, $phone, $pw, $address);
            $ins->execute();
            $cust_id = $conn->insert_id;
        }

        // Get plumber charge
        $pInfo = $conn->query("SELECT service_charge FROM plumbers WHERE id=$pid")->fetch_assoc();
        $charge = $pInfo['service_charge'] ?? 0;

        $bkStmt = $conn->prepare("INSERT INTO bookings (customer_id,plumber_id,service_type,problem_desc,address,booking_date,booking_time,total_charge) VALUES (?,?,?,?,?,?,?,?)");
        $bkStmt->bind_param('iisssssd', $cust_id, $pid, $svc_type, $problem, $address, $bdate, $btime, $charge);
        $bkStmt->execute();

        setFlash('success', '✅ Booking confirmed! The plumber will contact you shortly.');
        redirect(APP_URL . '/pages/booking.php');
    }
}

require_once '../includes/header.php';
?>

<section class="breadcrumb-section">
  <div class="container">
    <h1 class="breadcrumb-title">Book a Service</h1>
    <nav class="breadcrumb-custom">
      <div class="item"><a href="<?php echo APP_URL; ?>/index.php">Home</a></div>
      <div class="separator"><i class="fas fa-chevron-right"></i></div>
      <div class="item active">Book a Plumber</div>
    </nav>
  </div>
</section>

<section class="form-section section-padding">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-8">

        <?php if (!empty($errors)): ?>
        <div class="alert-custom danger mb-4"><i class="fas fa-times-circle"></i>
          <ul class="mb-0 ps-3"><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul>
        </div>
        <?php endif; ?>

        <div class="form-card">
          <div class="form-card-header">
            <div class="form-card-icon"><i class="fas fa-calendar-check"></i></div>
            <h2 class="section-title mb-1" style="font-size:1.75rem">Book a <span>Plumber</span></h2>
            <p class="text-muted">Fill in the details below and we'll arrange a plumber for you.</p>
          </div>

          <form method="POST" id="bookingForm" novalidate>
            <div class="row g-4">
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-user"></i> Full Name <span class="required">*</span></label>
                  <input type="text" name="cname" class="form-control-custom" placeholder="Your full name" value="<?php echo htmlspecialchars($_POST['cname'] ?? ''); ?>" required>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-phone-alt"></i> Mobile Number <span class="required">*</span></label>
                  <input type="tel" name="phone" class="form-control-custom" placeholder="10-digit mobile number" maxlength="10" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" required>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-envelope"></i> Email</label>
                  <input type="email" name="email" class="form-control-custom" placeholder="your@email.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-tools"></i> Service Type <span class="required">*</span></label>
                  <select name="service_type" class="form-control-custom" required>
                    <option value="">Select service...</option>
                    <?php foreach ($services as $svc): ?>
                    <option value="<?php echo htmlspecialchars($svc['name']); ?>" <?php echo (($_POST['service_type'] ?? '')===$svc['name'])?'selected':''; ?>><?php echo htmlspecialchars($svc['name']); ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-hard-hat"></i> Select Plumber <span class="required">*</span></label>
                  <select name="plumber_id" class="form-control-custom" required>
                    <option value="">Choose a plumber...</option>
                    <?php foreach ($allPlumbers as $pl): ?>
                    <option value="<?php echo $pl['id']; ?>" <?php echo (($plumber['id'] ?? 0)===$pl['id'])?'selected':''; ?>>
                      <?php echo htmlspecialchars($pl['name']); ?> — <?php echo htmlspecialchars($pl['service_area']); ?>
                    </option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-calendar"></i> Date <span class="required">*</span></label>
                  <input type="date" name="bdate" class="form-control-custom" min="<?php echo date('Y-m-d'); ?>" value="<?php echo htmlspecialchars($_POST['bdate'] ?? ''); ?>" required>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-clock"></i> Time <span class="required">*</span></label>
                  <input type="time" name="btime" class="form-control-custom" value="<?php echo htmlspecialchars($_POST['btime'] ?? ''); ?>" required>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-map-marker-alt"></i> Full Address <span class="required">*</span></label>
                  <textarea name="address" class="form-control-custom" rows="2" placeholder="Door no, street, area, city..." required><?php echo htmlspecialchars($_POST['address'] ?? ''); ?></textarea>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-comment-alt"></i> Problem Description <span class="required">*</span></label>
                  <textarea name="problem" class="form-control-custom" rows="4" placeholder="Describe your plumbing issue in detail..." required><?php echo htmlspecialchars($_POST['problem'] ?? ''); ?></textarea>
                </div>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-accent btn-block btn-lg">
                  <i class="fas fa-calendar-check"></i> Confirm Booking
                </button>
              </div>
            </div>
          </form>
        </div>

      </div>
    </div>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
