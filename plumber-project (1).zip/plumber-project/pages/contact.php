<?php
// pages/contact.php
require_once '../includes/config.php';
$pageTitle = 'Contact Us';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = sanitize($_POST['name']    ?? '');
    $email   = sanitize($_POST['email']   ?? '');
    $phone   = sanitize($_POST['phone']   ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $message = sanitize($_POST['message'] ?? '');
    $errors  = [];

    if (!$name)    $errors[] = 'Name required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required.';
    if (!$message) $errors[] = 'Message required.';

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO contacts (name,email,phone,subject,message) VALUES (?,?,?,?,?)");
        $stmt->bind_param('sssss', $name, $email, $phone, $subject, $message);
        $stmt->execute();
        setFlash('success', '✅ Thank you! We will get back to you within 24 hours.');
        redirect(APP_URL . '/pages/contact.php');
    }
}

require_once '../includes/header.php';
?>

<section class="breadcrumb-section">
  <div class="container">
    <h1 class="breadcrumb-title">Contact Us</h1>
    <nav class="breadcrumb-custom">
      <div class="item"><a href="<?php echo APP_URL; ?>/index.php">Home</a></div>
      <div class="separator"><i class="fas fa-chevron-right"></i></div>
      <div class="item active">Contact</div>
    </nav>
  </div>
</section>

<section class="contact-section section-padding">
  <div class="container">
    <div class="text-center mb-5">
      <h2 class="section-title">Get In <span>Touch</span></h2>
      <div class="title-underline mx-auto"></div>
      <p class="section-subtitle">Have questions? We're here to help you 24/7.</p>
    </div>

    <div class="row g-5">
      <!-- Info -->
      <div class="col-lg-4">
        <div class="contact-info-card">
          <div class="contact-info-item">
            <div class="contact-icon blue"><i class="fas fa-map-marker-alt"></i></div>
            <div>
              <div class="contact-info-label">Our Address</div>
              <div class="contact-info-value">MG Road, Vijayawada, Andhra Pradesh – 520010</div>
            </div>
          </div>
          <div class="contact-info-item">
            <div class="contact-icon orange"><i class="fas fa-phone-alt"></i></div>
            <div>
              <div class="contact-info-label">Phone Number</div>
              <div class="contact-info-value"><a href="tel:+919876543210">+91 98765 43210</a></div>
            </div>
          </div>
          <div class="contact-info-item">
            <div class="contact-icon green"><i class="fas fa-envelope"></i></div>
            <div>
              <div class="contact-info-label">Email Address</div>
              <div class="contact-info-value"><a href="mailto:info@plumberpro.com">info@plumberpro.com</a></div>
            </div>
          </div>
          <div class="contact-info-item">
            <div class="contact-icon blue"><i class="fas fa-clock"></i></div>
            <div>
              <div class="contact-info-label">Working Hours</div>
              <div class="contact-info-value">Mon–Sat: 8:00 AM – 8:00 PM</div>
            </div>
          </div>

          <div class="social-links-inline">
            <a href="#" class="social-btn facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="social-btn twitter"><i class="fab fa-twitter"></i></a>
            <a href="#" class="social-btn instagram"><i class="fab fa-instagram"></i></a>
            <a href="https://wa.me/919876543210" class="social-btn whatsapp"><i class="fab fa-whatsapp"></i></a>
          </div>
        </div>

        <!-- Map -->
        <div class="map-container mt-4">
          <iframe src="https://maps.google.com/maps?q=Vijayawada,Andhra+Pradesh&output=embed" allowfullscreen loading="lazy"></iframe>
        </div>
      </div>

      <!-- Form -->
      <div class="col-lg-8">
        <div class="contact-form-card">
          <h3 class="section-title mb-4" style="font-size:1.5rem">Send Us a <span>Message</span></h3>

          <?php if (!empty($errors)): ?>
          <div class="alert-custom danger mb-4"><i class="fas fa-times-circle"></i>
            <ul class="mb-0 ps-3"><?php foreach($errors as $e) echo "<li>$e</li>"; ?></ul>
          </div>
          <?php endif; ?>

          <form method="POST" id="contactForm" novalidate>
            <div class="row g-4">
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-user"></i> Your Name <span class="required">*</span></label>
                  <input type="text" name="name" class="form-control-custom" placeholder="Full name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-envelope"></i> Email <span class="required">*</span></label>
                  <input type="email" name="email" class="form-control-custom" placeholder="your@email.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-phone-alt"></i> Phone</label>
                  <input type="tel" name="phone" class="form-control-custom" placeholder="Mobile number" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-tag"></i> Subject</label>
                  <input type="text" name="subject" class="form-control-custom" placeholder="Subject of your message" value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>">
                </div>
              </div>
              <div class="col-12">
                <div class="form-group-custom">
                  <label class="form-label-custom"><i class="fas fa-comment-alt"></i> Message <span class="required">*</span></label>
                  <textarea name="message" class="form-control-custom" rows="6" placeholder="Type your message here..." required><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
                </div>
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-primary-custom btn-lg">
                  <i class="fas fa-paper-plane"></i> Send Message
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
