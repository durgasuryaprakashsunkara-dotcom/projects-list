<?php
// pages/plumbers.php — Find Plumber Listing
require_once '../includes/config.php';
$pageTitle = 'Find Plumbers';

// Filters
$location = sanitize($_GET['location'] ?? '');
$service  = sanitize($_GET['service']  ?? '');
$sort     = sanitize($_GET['sort']     ?? 'rating');

// Build query
$where = ["p.status = 'active'"];
if ($location) $where[] = "p.service_area LIKE '%" . $conn->real_escape_string($location) . "%'";

$orderMap = ['rating'=>'p.rating DESC','price_low'=>'p.service_charge ASC','price_high'=>'p.service_charge DESC','exp'=>'p.experience DESC'];
$orderBy  = $orderMap[$sort] ?? 'p.rating DESC';

$sql      = "SELECT * FROM plumbers p WHERE " . implode(' AND ', $where) . " ORDER BY $orderBy";
$result   = $conn->query($sql);
$plumbers = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Services for filter
$services = $conn->query("SELECT * FROM services WHERE status=1")->fetch_all(MYSQLI_ASSOC);

require_once '../includes/header.php';
?>

<!-- Breadcrumb -->
<section class="breadcrumb-section">
  <div class="container">
    <h1 class="breadcrumb-title">Find a Plumber</h1>
    <nav class="breadcrumb-custom">
      <div class="item"><a href="<?php echo APP_URL; ?>/index.php">Home</a></div>
      <div class="separator"><i class="fas fa-chevron-right"></i></div>
      <div class="item active">Find Plumber</div>
    </nav>
  </div>
</section>

<section class="plumbers-section section-padding">
  <div class="container">

    <!-- Search Bar -->
    <form method="GET" class="search-card mb-5">
      <div class="search-form">
        <div class="search-input-group">
          <i class="fas fa-map-marker-alt input-icon"></i>
          <input type="text" name="location" class="form-control-custom" placeholder="City or Area..." value="<?php echo htmlspecialchars($location); ?>">
        </div>
        <div class="search-input-group">
          <i class="fas fa-tools input-icon"></i>
          <select name="service" class="form-control-custom">
            <option value="">All Services</option>
            <?php foreach ($services as $svc): ?>
            <option value="<?php echo htmlspecialchars($svc['name']); ?>" <?php echo $service==$svc['name']?'selected':''; ?>>
              <?php echo htmlspecialchars($svc['name']); ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="btn-search"><i class="fas fa-search"></i> Search</button>
      </div>
    </form>

    <!-- Filter Bar -->
    <div class="filter-bar mb-4">
      <span class="filter-label">Sort By:</span>
      <?php
      $sorts = ['rating'=>'Top Rated','price_low'=>'Price: Low','price_high'=>'Price: High','exp'=>'Experience'];
      foreach ($sorts as $key => $label):
      ?>
      <a href="?location=<?php echo urlencode($location); ?>&service=<?php echo urlencode($service); ?>&sort=<?php echo $key; ?>"
         class="filter-btn <?php echo $sort==$key?'active':''; ?>"><?php echo $label; ?></a>
      <?php endforeach; ?>
      <span class="ms-auto text-muted" style="font-size:var(--font-size-sm)"><?php echo count($plumbers); ?> plumbers found</span>
    </div>

    <!-- Plumber Grid -->
    <?php if (empty($plumbers)): ?>
    <div class="text-center py-5">
      <i class="fas fa-search fa-3x text-muted mb-3"></i>
      <h4 class="text-muted">No plumbers found for your search.</h4>
      <a href="plumbers.php" class="btn btn-primary-custom mt-3">Clear Filters</a>
    </div>
    <?php else: ?>
    <div class="row g-4">
      <?php foreach ($plumbers as $p): ?>
      <div class="col-lg-3 col-md-6">
        <div class="plumber-card">
          <div class="plumber-card-header">
            <span class="plumber-card-badge"><?php echo $p['status']==='active'?'Available':'Offline'; ?></span>
            <img src="<?php echo UPLOAD_URL . htmlspecialchars($p['profile_image']); ?>"
                 onerror="this.src='<?php echo APP_URL; ?>/images/default-avatar.png'"
                 alt="<?php echo htmlspecialchars($p['name']); ?>" class="plumber-avatar">
          </div>
          <div class="plumber-card-body">
            <div class="plumber-name"><?php echo htmlspecialchars($p['name']); ?></div>
            <div class="plumber-specialty">Professional Plumber</div>
            <div class="rating-stars justify-content-center d-flex gap-1 mb-3">
              <?php for ($i=1;$i<=5;$i++): ?>
                <i class="fas fa-star star<?php echo $i<=$p['rating']?'':' empty'; ?>"></i>
              <?php endfor; ?>
              <span class="rating-count">(<?php echo $p['total_reviews']; ?>)</span>
            </div>
            <ul class="plumber-info-list">
              <li><i class="fas fa-briefcase"></i><span><?php echo $p['experience']; ?> Years Exp.</span></li>
              <li><i class="fas fa-map-marker-alt"></i><span><?php echo htmlspecialchars($p['service_area']); ?></span></li>
              <li><i class="fas fa-phone-alt"></i><span><?php echo htmlspecialchars($p['phone']); ?></span></li>
              <li><i class="fas fa-rupee-sign"></i><span>₹<?php echo number_format($p['service_charge'],0); ?>/visit</span></li>
            </ul>
            <div class="plumber-card-footer">
              <a href="plumber-detail.php?id=<?php echo $p['id']; ?>" class="btn btn-primary-custom btn-sm">View Details</a>
              <a href="booking.php?plumber_id=<?php echo $p['id']; ?>" class="btn btn-accent btn-sm">Book Now</a>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
