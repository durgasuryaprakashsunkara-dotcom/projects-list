<?php
// pages/plumber-detail.php
require_once '../includes/config.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { setFlash('danger','Invalid plumber.'); redirect(APP_URL.'/pages/plumbers.php'); }

$stmt = $conn->prepare("SELECT * FROM plumbers WHERE id=? AND status='active'");
$stmt->bind_param('i', $id);
$stmt->execute();
$plumber = $stmt->get_result()->fetch_assoc();
if (!$plumber) { setFlash('danger','Plumber not found.'); redirect(APP_URL.'/pages/plumbers.php'); }

// Reviews
$revResult = $conn->query("SELECT r.*,c.name AS cname FROM reviews r JOIN customers c ON r.customer_id=c.id WHERE r.plumber_id=$id ORDER BY r.created_at DESC LIMIT 10");
$reviews   = $revResult ? $revResult->fetch_all(MYSQLI_ASSOC) : [];

$pageTitle = htmlspecialchars($plumber['name']) . ' – Plumber Details';
require_once '../includes/header.php';
?>

<section class="breadcrumb-section">
  <div class="container">
    <h1 class="breadcrumb-title"><?php echo htmlspecialchars($plumber['name']); ?></h1>
    <nav class="breadcrumb-custom">
      <div class="item"><a href="<?php echo APP_URL; ?>/index.php">Home</a></div>
      <div class="separator"><i class="fas fa-chevron-right"></i></div>
      <div class="item"><a href="plumbers.php">Find Plumber</a></div>
      <div class="separator"><i class="fas fa-chevron-right"></i></div>
      <div class="item active"><?php echo htmlspecialchars($plumber['name']); ?></div>
    </nav>
  </div>
</section>

<section class="plumber-detail-page section-padding">
  <div class="container">
    <div class="row g-5">

      <!-- Profile Card -->
      <div class="col-lg-4">
        <div class="plumber-profile-card sticky-top" style="top:90px">
          <div class="plumber-profile-header">
            <img src="<?php echo UPLOAD_URL.htmlspecialchars($plumber['profile_image']); ?>"
                 onerror="this.src='<?php echo APP_URL; ?>/images/default-avatar.png'"
                 class="profile-avatar-large" alt="<?php echo htmlspecialchars($plumber['name']); ?>">
            <div class="profile-name"><?php echo htmlspecialchars($plumber['name']); ?></div>
            <div class="profile-specialty">Professional Plumber</div>
          </div>
          <div class="plumber-profile-body">
            <!-- Rating -->
            <div class="text-center mb-4">
              <div class="rating-stars justify-content-center d-flex gap-1">
                <?php for($i=1;$i<=5;$i++): ?>
                  <i class="fas fa-star star<?php echo $i<=$plumber['rating']?'':' empty'; ?>" style="font-size:1.2rem"></i>
                <?php endfor; ?>
              </div>
              <small class="text-muted"><?php echo $plumber['rating']; ?>/5 (<?php echo $plumber['total_reviews']; ?> reviews)</small>
            </div>

            <!-- Info Grid -->
            <div class="detail-info-grid">
              <div class="detail-info-item">
                <span class="detail-info-label">Experience</span>
                <span class="detail-info-value"><i class="fas fa-briefcase"></i><?php echo $plumber['experience']; ?> Years</span>
              </div>
              <div class="detail-info-item">
                <span class="detail-info-label">Charge</span>
                <span class="detail-info-value"><i class="fas fa-rupee-sign"></i>₹<?php echo number_format($plumber['service_charge'],0); ?>/visit</span>
              </div>
              <div class="detail-info-item">
                <span class="detail-info-label">Phone</span>
                <span class="detail-info-value"><i class="fas fa-phone-alt"></i><?php echo htmlspecialchars($plumber['phone']); ?></span>
              </div>
              <div class="detail-info-item">
                <span class="detail-info-label">Service Area</span>
                <span class="detail-info-value"><i class="fas fa-map-marker-alt"></i><?php echo htmlspecialchars($plumber['service_area']); ?></span>
              </div>
            </div>

            <!-- Availability -->
            <div class="availability-card">
              <div class="availability-title"><i class="fas fa-clock"></i> Availability</div>
              <div class="day-slots">
                <?php
                $days = ['Monday'=>'8AM–6PM','Tuesday'=>'8AM–6PM','Wednesday'=>'8AM–6PM','Thursday'=>'8AM–6PM','Friday'=>'8AM–6PM','Saturday'=>'8AM–4PM','Sunday'=>'Closed'];
                foreach ($days as $day => $time):
                ?>
                <div class="day-slot">
                  <span class="day"><?php echo $day; ?></span>
                  <span class="<?php echo $time==='Closed'?'closed':'time'; ?>"><?php echo $time; ?></span>
                </div>
                <?php endforeach; ?>
              </div>
            </div>

            <a href="booking.php?plumber_id=<?php echo $plumber['id']; ?>" class="btn btn-accent btn-block btn-lg">
              <i class="fas fa-calendar-check"></i> Book This Plumber
            </a>
          </div>
        </div>
      </div>

      <!-- Details & Reviews -->
      <div class="col-lg-8">
        <!-- Bio -->
        <div class="mb-5">
          <h3 class="section-title mb-3" style="font-size:1.5rem">About <span><?php echo htmlspecialchars($plumber['name']); ?></span></h3>
          <p class="text-muted" style="line-height:1.8"><?php echo htmlspecialchars($plumber['bio'] ?: 'Experienced professional plumber providing quality services.'); ?></p>
        </div>

        <!-- Reviews -->
        <div>
          <h3 class="section-title mb-4" style="font-size:1.5rem">Customer <span>Reviews</span> (<?php echo count($reviews); ?>)</h3>
          <?php if (empty($reviews)): ?>
            <p class="text-muted">No reviews yet. Be the first to book and review!</p>
          <?php else: ?>
            <?php foreach ($reviews as $rev): ?>
            <div class="review-card">
              <div class="review-header">
                <div class="reviewer-avatar d-flex align-items-center justify-content-center" style="background:var(--light-bg);color:var(--primary);font-weight:700;font-size:1.1rem">
                  <?php echo strtoupper(substr($rev['cname'],0,1)); ?>
                </div>
                <div>
                  <div class="reviewer-name"><?php echo htmlspecialchars($rev['cname']); ?></div>
                  <div class="review-date"><?php echo date('d M Y', strtotime($rev['created_at'])); ?></div>
                  <div class="rating-stars d-flex gap-1 mt-1">
                    <?php for($i=1;$i<=5;$i++): ?><i class="fas fa-star star<?php echo $i<=$rev['rating']?'':' empty'; ?>" style="font-size:.75rem"></i><?php endfor; ?>
                  </div>
                </div>
              </div>
              <p class="review-text"><?php echo htmlspecialchars($rev['comment']); ?></p>
            </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
