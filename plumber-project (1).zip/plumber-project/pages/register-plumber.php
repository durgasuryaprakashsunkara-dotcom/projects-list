<?php
// pages/register-plumber.php
require_once '../includes/config.php';
$pageTitle = 'Register as Plumber';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = sanitize($_POST['name']     ?? '');
    $email    = sanitize($_POST['email']    ?? '');
    $phone    = sanitize($_POST['phone']    ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm']  ?? '';
    $exp      = (int)($_POST['experience'] ?? 0);
    $area     = sanitize($_POST['service_area'] ?? '');
    $charge   = (float)($_POST['charge'] ?? 0);

    if (!$name)   $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email required.';
    if (strlen($phone) < 10) $errors[] = 'Valid 10-digit phone required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';
    if (!$area) $errors[] = 'Service area is required.';

    if (empty($errors)) {
        // Check duplicate
        $chk = $conn->prepare("SELECT id FROM plumbers WHERE email=? OR phone=?");
        $chk->bind_param('ss', $email, $phone);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $errors[] = 'Email or phone already registered.';
        } else {
            $image = 'default.png';
            if (!empty($_FILES['profile_image']['name'])) {
                $uploaded = uploadImage($_FILES['profile_image']);
                if ($uploaded) $image = $uploaded;
                else $errors[] = 'Invalid image. Use JPG/PNG under 2MB.';
            }

            if (empty($errors)) {
                $pw  = hashPassword($password);
                $ins = $conn->prepare("INSERT INTO plumbers (name,email,phone,password,experience,service_area,service_charge,profile_image) VALUES (?,?,?,?,?,?,?,?)");
                $ins->bind_param('ssssisss', $name, $email, $phone, $pw, $exp, $area, $charge, $image);
                $ins->execute();
                setFlash('success', '🎉 Registration successful! Your profile is under review.');
                redirect(APP_URL . '/pages/login.php');
            }
        }
    }
}

require_once '../includes/header.php';
?>

<section class="breadcrumb-section">
  <div class="container">
    <h1 class="breadcrumb-title">Register as Plumber</h1>
    <nav class="breadcrumb-custom">
      <div class="item"><a href="<?php echo APP_URL; ?>/index.php">Home</a></div>
      <div class="separator"><i class="fas fa-chevron-right"></i></div>
      <div class="item active">Register</div>
    </nav>
  </div>
</section>

<section class="registration-section section-padding">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-xl-10">

        <?php if (!empty($errors)): ?>
        <div class="alert-custom danger mb-4"><i class="fas fa-times-circle"></i>
          <ul class="mb-0 ps-3"><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul>
        </div>
        <?php endif; ?>

        <div class="registration-card">
          <!-- Sidebar -->
          <div class="registration-sidebar">
            <div class="sidebar-title">Join PlumberPro</div>
            <p class="sidebar-text">Register as a professional plumber and start receiving bookings from customers in your area.</p>
            <div class="registration-benefits">
              <div class="benefit-item"><i class="fas fa-users"></i><span>Access thousands of customers</span></div>
              <div class="benefit-item"><i class="fas fa-rupee-sign"></i><span>Earn more with online bookings</span></div>
              <div class="benefit-item"><i class="fas fa-shield-alt"></i><span>Verified badge on your profile</span></div>
              <div class="benefit-item"><i class="fas fa-star"></i><span>Build your reputation with reviews</span></div>
              <div class="benefit-item"><i class="fas fa-headset"></i><span>24/7 support from our team</span></div>
            </div>
          </div>

          <!-- Form -->
          <div class="registration-form-area">
            <h3 class="mb-1" style="font-weight:800;color:var(--text-dark)">Create Your Account</h3>
            <p class="text-muted mb-5">Fill in the form below. Your profile will be reviewed within 24 hours.</p>

            <form method="POST" enctype="multipart/form-data" id="regForm" novalidate>

              <!-- Photo Upload -->
              <div class="profile-upload-area" onclick="document.getElementById('profileImg').click()">
                <div class="profile-upload-circle" id="uploadCircle">
                  <i class="fas fa-camera"></i>
                  <span>Upload Photo</span>
                  <img src="" alt="Preview" id="imgPreview">
                </div>
                <div class="upload-hint">JPG/PNG, Max 2MB</div>
                <input type="file" name="profile_image" id="profileImg" accept="image/*" style="display:none">
              </div>

              <div class="row g-4">
                <div class="col-md-6">
                  <div class="form-group-custom">
                    <label class="form-label-custom"><i class="fas fa-user"></i> Full Name <span class="required">*</span></label>
                    <input type="text" name="name" class="form-control-custom" placeholder="Your full name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group-custom">
                    <label class="form-label-custom"><i class="fas fa-phone-alt"></i> Mobile Number <span class="required">*</span></label>
                    <input type="tel" name="phone" class="form-control-custom" placeholder="10-digit number" maxlength="10" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group-custom">
                    <label class="form-label-custom"><i class="fas fa-envelope"></i> Email <span class="required">*</span></label>
                    <input type="email" name="email" class="form-control-custom" placeholder="your@email.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group-custom">
                    <label class="form-label-custom"><i class="fas fa-briefcase"></i> Years of Experience <span class="required">*</span></label>
                    <input type="number" name="experience" class="form-control-custom" placeholder="e.g. 5" min="0" max="50" value="<?php echo htmlspecialchars($_POST['experience'] ?? ''); ?>" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group-custom">
                    <label class="form-label-custom"><i class="fas fa-map-marker-alt"></i> Service Area <span class="required">*</span></label>
                    <input type="text" name="service_area" class="form-control-custom" placeholder="e.g. Vijayawada, Guntur" value="<?php echo htmlspecialchars($_POST['service_area'] ?? ''); ?>" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group-custom">
                    <label class="form-label-custom"><i class="fas fa-rupee-sign"></i> Service Charge (₹/visit)</label>
                    <input type="number" name="charge" class="form-control-custom" placeholder="e.g. 500" min="0" value="<?php echo htmlspecialchars($_POST['charge'] ?? ''); ?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group-custom">
                    <label class="form-label-custom"><i class="fas fa-lock"></i> Password <span class="required">*</span></label>
                    <input type="password" name="password" id="pw1" class="form-control-custom" placeholder="Min 6 characters" required>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group-custom">
                    <label class="form-label-custom"><i class="fas fa-lock"></i> Confirm Password <span class="required">*</span></label>
                    <input type="password" name="confirm" id="pw2" class="form-control-custom" placeholder="Re-enter password" required>
                  </div>
                </div>
                <div class="col-12">
                  <button type="submit" class="btn btn-primary-custom btn-block btn-lg">
                    <i class="fas fa-user-plus"></i> Register as Plumber
                  </button>
                  <p class="text-center mt-3 text-muted" style="font-size:.875rem">Already have an account? <a href="login.php" style="color:var(--primary);font-weight:600">Login here</a></p>
                </div>
              </div>
            </form>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>

<?php require_once '../includes/footer.php'; ?>
