-- ============================================================
-- PLUMBER PRO — MySQL Database Schema
-- Database: plumber_db
-- ============================================================

CREATE DATABASE IF NOT EXISTS plumber_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE plumber_db;

-- ============================================================
-- TABLE: admins
-- ============================================================
CREATE TABLE IF NOT EXISTS admins (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)  NOT NULL,
    email       VARCHAR(150)  NOT NULL UNIQUE,
    password    VARCHAR(255)  NOT NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: plumbers
-- ============================================================
CREATE TABLE IF NOT EXISTS plumbers (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100)  NOT NULL,
    email         VARCHAR(150)  NOT NULL UNIQUE,
    phone         VARCHAR(20)   NOT NULL,
    password      VARCHAR(255)  NOT NULL,
    experience    INT           DEFAULT 0 COMMENT 'Years of experience',
    service_area  VARCHAR(200)  NOT NULL,
    service_charge DECIMAL(10,2) DEFAULT 0.00,
    profile_image VARCHAR(255)  DEFAULT 'default.png',
    bio           TEXT,
    availability  VARCHAR(100)  DEFAULT 'Mon-Sat 8AM-6PM',
    rating        DECIMAL(3,1)  DEFAULT 0.0,
    total_reviews INT           DEFAULT 0,
    status        ENUM('active','inactive','pending') DEFAULT 'pending',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: customers
-- ============================================================
CREATE TABLE IF NOT EXISTS customers (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)  NOT NULL,
    email       VARCHAR(150)  NOT NULL UNIQUE,
    phone       VARCHAR(20)   NOT NULL,
    password    VARCHAR(255)  NOT NULL,
    address     TEXT,
    status      ENUM('active','inactive') DEFAULT 'active',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: bookings
-- ============================================================
CREATE TABLE IF NOT EXISTS bookings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    customer_id     INT          NOT NULL,
    plumber_id      INT          NOT NULL,
    service_type    VARCHAR(100) NOT NULL,
    problem_desc    TEXT         NOT NULL,
    address         TEXT         NOT NULL,
    booking_date    DATE         NOT NULL,
    booking_time    TIME         NOT NULL,
    status          ENUM('pending','confirmed','in_progress','completed','cancelled') DEFAULT 'pending',
    total_charge    DECIMAL(10,2) DEFAULT 0.00,
    admin_notes     TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (plumber_id)  REFERENCES plumbers(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: reviews
-- ============================================================
CREATE TABLE IF NOT EXISTS reviews (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    booking_id  INT  NOT NULL,
    customer_id INT  NOT NULL,
    plumber_id  INT  NOT NULL,
    rating      TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment     TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id)  REFERENCES bookings(id)  ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (plumber_id)  REFERENCES plumbers(id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: contacts
-- ============================================================
CREATE TABLE IF NOT EXISTS contacts (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL,
    phone       VARCHAR(20),
    subject     VARCHAR(200),
    message     TEXT         NOT NULL,
    is_read     TINYINT(1)   DEFAULT 0,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- TABLE: services
-- ============================================================
CREATE TABLE IF NOT EXISTS services (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    icon        VARCHAR(50)  DEFAULT 'fas fa-wrench',
    description TEXT,
    status      TINYINT(1)   DEFAULT 1,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Default Admin (password: admin123)
INSERT INTO admins (name, email, password) VALUES
('Super Admin', 'admin@plumberpro.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Sample Services
INSERT INTO services (name, icon, description) VALUES
('Pipe Repair',        'fas fa-tools',        'Fix leaking or broken pipes quickly'),
('Drain Cleaning',     'fas fa-water',        'Unclog blocked drains and sewers'),
('Water Heater',       'fas fa-fire',         'Installation and repair of water heaters'),
('Bathroom Fitting',   'fas fa-bath',         'Complete bathroom plumbing solutions'),
('Leak Detection',     'fas fa-search',       'Advanced leak detection services'),
('Emergency Plumbing', 'fas fa-ambulance',    '24/7 emergency plumbing assistance');

-- Sample Plumbers (password: plumber123)
INSERT INTO plumbers (name, email, phone, password, experience, service_area, service_charge, profile_image, bio, rating, total_reviews, status) VALUES
('Rajesh Kumar',   'rajesh@example.com',  '9876543210', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 8,  'Vijayawada, Amaravati',  500.00, 'plumber1.jpg', 'Expert in all types of plumbing repairs.', 4.8, 120, 'active'),
('Suresh Babu',    'suresh@example.com',  '9876543211', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 5,  'Guntur, Tenali',         400.00, 'plumber2.jpg', 'Specialised in drain cleaning and pipe repairs.', 4.5, 87, 'active'),
('Venkat Rao',     'venkat@example.com',  '9876543212', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 12, 'Vijayawada',             600.00, 'plumber3.jpg', 'Senior plumber with 12 years of experience.', 4.9, 200, 'active'),
('Anil Sharma',    'anil@example.com',    '9876543213', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3,  'Machilipatnam, Krishna', 350.00, 'plumber4.jpg', 'Young and energetic plumber for quick fixes.', 4.2, 45, 'active');

-- Sample Customer (password: customer123)
INSERT INTO customers (name, email, phone, password, address) VALUES
('Priya Devi', 'priya@example.com', '9123456789', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Flat 5B, MG Road, Vijayawada');

-- ============================================================
-- USEFUL VIEWS
-- ============================================================

CREATE OR REPLACE VIEW v_booking_details AS
SELECT
    b.id              AS booking_id,
    b.service_type,
    b.problem_desc,
    b.address         AS booking_address,
    b.booking_date,
    b.booking_time,
    b.status,
    b.total_charge,
    b.created_at,
    c.name            AS customer_name,
    c.phone           AS customer_phone,
    c.email           AS customer_email,
    p.name            AS plumber_name,
    p.phone           AS plumber_phone,
    p.service_area,
    p.profile_image
FROM bookings b
JOIN customers c ON b.customer_id = c.id
JOIN plumbers  p ON b.plumber_id  = p.id;

CREATE OR REPLACE VIEW v_plumber_stats AS
SELECT
    p.id,
    p.name,
    p.phone,
    p.service_area,
    p.service_charge,
    p.experience,
    p.rating,
    p.total_reviews,
    p.status,
    COUNT(b.id) AS total_bookings,
    SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END) AS completed_bookings
FROM plumbers p
LEFT JOIN bookings b ON p.id = b.plumber_id
GROUP BY p.id;
